function toggleMenu() {
  let menu = document.querySelector("#main-menu");
  menu.classList.toggle("show-small");
}