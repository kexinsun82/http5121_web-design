function toggleMenu() {
  let menu = document.getElementById("main-menu");
  menu.classList.toggle("show-small");
}